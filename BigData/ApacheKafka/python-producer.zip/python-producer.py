from kafka import KafkaProducer
import json

def CreateKafkaProducer():
  """https://kafka-python.readthedocs.io/en/master/apidoc/KafkaProducer.html"""
  bootstrap_servers = "localhost:9092"
  producer = KafkaProducer(bootstrap_servers=bootstrap_servers)
  return producer


def SendMessagesToKafkaBroker(producer):
  topic_name = "alarms"
  
  JSON_generator = GenerateJSONData()
  for JSON_data in JSON_generator:
    #PrintDataEveryNowAndThen(JSON_data)
    binary_JSON = EncodeToBinaryUTF(JSON_data)
    producer.send(topic=topic_name, value=binary_JSON)

def GenerateJSONData():
  data_generator = GenerateDataFromCSV()
  
  for data in data_generator:
    JSON_data = ConvertToJSON(data)
    yield JSON_data


def GenerateDataFromCSV():
  filename = "data.txt"

  with open(filename) as alarms:
    for alarm in alarms:
      values = SplitCSV(alarm)
      clean_values = CleanUpValues(values)

      yield clean_values


def SplitCSV(CSVs):
  separator = ","

  split_values = CSVs.split(separator)
  return split_values

def CleanUpValues(dirty_values):
  dirty_values = RemoveWhiteSpaces(dirty_values)
  dirty_values = RemoveDoubleQuotes(dirty_values)
  dirty_values = SubstituteEmptyStrings(dirty_values)

  clean_values = dirty_values
  return clean_values
  
def RemoveWhiteSpaces(dirty_values):
  clean_values = []
  
  for dirty_value in dirty_values:
    clean_value = dirty_value.strip()
    clean_values.append(clean_value)
  
  return clean_values

def RemoveDoubleQuotes(dirty_values):
  clean_values = []
  
  for dirty_value in dirty_values:
    clean_value = dirty_value.strip("\"")
    clean_values.append(clean_value)

  return clean_values

def SubstituteEmptyStrings(dirty_values):
  substitute = None
  clean_values = [substitute if x == "" else x for x in dirty_values]
  return clean_values


def ConvertToJSON(values):
  keys = LoadKeys()
  
  value_key_pairs = {}
  length = len(keys)
  for pair in range(length):
    key = keys[pair]
    value = values[pair]
    value_key_pairs[key] = value
  
  JSON = json.dumps(value_key_pairs)

  return JSON

def LoadKeys():
  filename = "format.txt"

  with open(filename) as format_file:
    line = format_file.readline()
    dirty_keys = SplitCSV(line)
    keys = CleanUpValues(dirty_keys)

  return keys
  

def EncodeToBinaryUTF(string):
  return string.encode("utf-8")

  


producer = CreateKafkaProducer()
SendMessagesToKafkaBroker(producer)
producer.close()
"""TODO: create a context manager for producer"""

