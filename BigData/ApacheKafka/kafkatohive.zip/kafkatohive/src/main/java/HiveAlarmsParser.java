import java.time.Month;
import java.util.ArrayList;
import java.util.Map;

public class HiveAlarmsParser {

    private StringBuilder construct;

    public ArrayList<String> KafkaMapToCSV(Map<String, String> map){
        /* Kafka data example:
        {"info": "Modem IP: 10.204.78.230: CRITICAL - Socket timeout after 10 seconds",
        "ipadresa": "10.204.78.230",
        "status_code": "DOWN",
        "start_time": "2018/06/13 15:11:10",
        "eventname": "HOST ALERT",
        "state": "SOFT",
        "end_time": "2018/06/13 15:16:11"}*/
        SetStringBuilder();
        String start_time_alarm_message = GetStartTimeAlarmMessage(map);
        SetStringBuilder();
        String end_time_alarm_message = GetEndTimeAlarmMessage(map);

        ArrayList<String> messages = new ArrayList<>();
        messages.add(start_time_alarm_message);
        messages.add(end_time_alarm_message);

        return messages;
    }

    private void SetStringBuilder(){
        this.construct = new StringBuilder();
    }

    private void AddCSVStringToBuilder(String string){
        this.construct.append(string);
        this.construct.append(',');
    }

    private void DiscardLastCommaFromBuilder() {
        DiscardLastCharFromBuilder();
    }

    private void DiscardLastCharFromBuilder() {
        String string = this.construct.substring(0,this.construct.length()-1);
        SetStringBuilder();
        this.construct.append(string);
    }



    private String GetStartTimeAlarmMessage(Map<String, String> data){
        AddCSVStringToBuilder(ParseStartTime(data));
        AddStartTimeAlarmsColumnData(data);
        AddAlarmsPartitionData(data);
        DiscardLastCommaFromBuilder();

        //System.out.println("HiveAlarmsParser has parsed " + construct.toString());
        return construct.toString();
    }

    private String GetEndTimeAlarmMessage(Map<String, String> data) {
        AddCSVStringToBuilder(ParseEndTime(data));
        AddEndTimeAlarmsColumnData(data);
        AddAlarmsPartitionData(data);
        DiscardLastCommaFromBuilder();

        //System.out.println("HiveAlarmsParser has parsed " + construct.toString());
        return construct.toString();
    }

    private String ParseStartTime(Map<String, String> data){
        String raw_end_time = data.get("start_time");
        String hive_timestamp_string = TransformStringIntoHiveTimestampFormat(raw_end_time);
        return hive_timestamp_string;
    }

    private String ParseEndTime(Map<String, String> data){
        String raw_end_time = data.get("end_time");
        String hive_timestamp_string = TransformStringIntoHiveTimestampFormat(raw_end_time);
        return hive_timestamp_string;
    }

    private String TransformStringIntoHiveTimestampFormat(String raw_string){
        String hive_timestamp_string = raw_string.replace("/", "-");
        return hive_timestamp_string;
    }


    private void AddStartTimeAlarmsColumnData(Map<String, String> data) {
        AddCSVStringToBuilder(ParseState(data));
        AddCSVStringToBuilder(ParseStateCode(data));
        AddCSVStringToBuilder(ParseStatus(data));

        AddCSVStringToBuilder(ParseAlarmType(data));
        AddCSVStringToBuilder(ParseInfo(data));
    }

    private void AddEndTimeAlarmsColumnData(Map<String, String> data) {
        AddCSVStringToBuilder(ParseSetState(data));
        AddCSVStringToBuilder(SetStateCodeUp(data));
        AddCSVStringToBuilder(SetStatusZero(data));

        AddCSVStringToBuilder(ParseAlarmType(data));
        AddCSVStringToBuilder(ParseInfo(data));
    }

    private String ParseState(Map<String, String> data){
        return data.get("state");
    }

    private String ParseSetState(Map<String, String> data){
        return "HARD";
    }

    private String ParseStateCode(Map<String, String> data){
        return data.get("status_code");
    }

    private String SetStateCodeUp(Map<String, String> data){
        return "UP";
    }

    private String ParseStatus(Map<String, String> data){
        //UP == 0
        //DOWN == 1
        //WARNING == 2
        //CRITICAL == 3
        String status_code = data.get("status_code");
        String status;
        if (status_code.equals("UP")){
            status = "0";
        } else if (status_code.equals("DOWN")) {
            status = "1";
        }else if (status_code.equals("WARNING")) {
            status = "2";
        }else if (status_code.equals("CRITICAL")) {
            status = "3";
        } else {
            status = "7"; //7 for exception
        }
        return status;
    }

    private String SetStatusZero(Map<String, String> data){
        //UP == 0
        //DOWN == 1
        //WARNING == 2
        //CRITICAL == 3
        return "0";
    }

    private String ParseAlarmType(Map<String, String> data){
        String raw_alarm_type = data.get("eventname");
        String[] split_string = raw_alarm_type.split(" ");
        return split_string[0];
    }

    private String ParseInfo(Map<String, String> data){
        return data.get("info");
    }


    private void AddAlarmsPartitionData(Map<String, String> data) {
        AddCSVStringToBuilder(ParseYear(data));
        AddCSVStringToBuilder(ParseMonth(data));
        AddCSVStringToBuilder(ParseIP(data));
    }

    private String ParseYear(Map<String, String> data) {
        String raw_date = data.get("start_time");
        String[] split_date = raw_date.split("/");
        String year = split_date[0];
        return year;
    }

    private String ParseMonth(Map<String, String> data) {
        String raw_date = data.get("start_time");
        String[] split_date = raw_date.split("/");
        int month_number = Integer.parseInt(split_date[1]);
        String month = Month.of(month_number).toString();
        return month;
    }

    private String ParseIP(Map<String, String> data) {
        return data.get("ipadresa");
    }
}
