import org.apache.hive.hcatalog.streaming.StreamingException;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Map;

public class KafkaToHiveTransporter { //TODO, cleanup; move properties/configs to a file; automate coupled config discovery

    public static void main(String[] args) throws InterruptedException, StreamingException, ClassNotFoundException, JSONException {
        ArrayList<String> bootstrap_servers = new ArrayList<>();
        bootstrap_servers.add("192.168.50.56:9094");
        ArrayList<String> topics = new ArrayList<>();
        topics.add("alarms");
        KafkaDataConsumerConfiguration consumer_config = new KafkaDataConsumerConfiguration(StringDeserializer.class.getName(),
                StringDeserializer.class.getName(),
                bootstrap_servers,
                "hive_consumers",
                topics,
                5000);
        KafkaDataConsumer consumer = new KafkaDataConsumer(consumer_config);

        HiveEndPointConfiguration end_point_config = new HiveEndPointConfiguration("thrift://sandbox-hdp.hortonworks.com:9083",
                "default",
                "unpartitioned_alarms_raw",
                null); // NOTE: you can use dynamic partitioning; the last few columns will be the partition values (Hive 3.0.0!!!)
        StreamingConnectionConfiguration streaming_connection_config = new StreamingConnectionConfiguration(true,
                null);
        String[] unpartitioned_alarms_column_names = new String[]{"stamp", "state", "state_code", "status", "alarm_type", "info", "year", "month", "ip"}; //TODO read them from a source
        CSVWriterConfiguration csv_writer_config = new CSVWriterConfiguration(unpartitioned_alarms_column_names,
                ",",
                null,
                ',');
        TransactionBatchConfiguration transaction_batch_config = new TransactionBatchConfiguration(20);
        CommitControlConfiguration commit_control_config = new CommitControlConfiguration(10000);
        HiveStreamingConfig hive_streaming_config = new HiveStreamingConfig(end_point_config,
                streaming_connection_config,
                csv_writer_config,
                transaction_batch_config,
                commit_control_config);
        HiveStreamer hive_streamer = new HiveStreamer(hive_streaming_config);

        HiveAlarmsParser hive_alarms_parser = new HiveAlarmsParser();

        int max_kafka_queries = 1000; //TODO, better stopping conditions
        for (int query_counter = 0; query_counter < max_kafka_queries; query_counter++) {
            ArrayList<Map<String, String>> records = consumer.GetRecords();

            for (Map<String, String> map:records) {
                ArrayList<String> messages = hive_alarms_parser.KafkaMapToCSV(map);
                hive_streamer.TransactMessages(messages);
            }
            System.out.println("Kafka query " + query_counter + "/" + max_kafka_queries);
        }
        consumer.StopConsumer();
        hive_streamer.StopStreaming();
    }
}
