import org.apache.hive.hcatalog.streaming.StreamingException;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class KafkaToHiveTransporter { //TODO, cleanup; move properties/configs to a file; automate coupled config discovery

    public static void main(String[] args) throws InterruptedException, StreamingException, ClassNotFoundException {
        List<String> bootstrap_servers = new ArrayList<>();
        bootstrap_servers.add("192.168.50.56:9094");
        List<String> topics = new ArrayList<>();
        topics.add("alarms");
        KafkaDataConsumerConfiguration consumer_config = new KafkaDataConsumerConfiguration(StringDeserializer.class.getName(),
                StringDeserializer.class.getName(),
                bootstrap_servers,
                "hive_consumers",
                topics,
                2000);


        HiveEndPointConfiguration end_point_config = new HiveEndPointConfiguration("thrift://sandbox-hdp.hortonworks.com:9083",
                "default",
                "unpartitioned_alarms_raw",
                null);
        StreamingConnectionConfiguration streaming_connection_config = new StreamingConnectionConfiguration(true,
                null);
        String[] unpartitioned_alarms_column_names = new String[]{"stamp", "state", "state_code", "status", "alarm_type", "info", "year", "month", "ip"}; //TODO couple them with the table
        CSVWriterConfiguration csv_writer_config = new CSVWriterConfiguration(unpartitioned_alarms_column_names,
                ",",
                null,
                ',');
        TransactionBatchConfiguration transaction_batch_config = new TransactionBatchConfiguration(200);
        CommitControlConfiguration commit_control_config = new CommitControlConfiguration(10000);
        HiveStreamingConfig hive_streaming_config = new HiveStreamingConfig(end_point_config,
                streaming_connection_config,
                csv_writer_config,
                transaction_batch_config,
                commit_control_config);


        HiveKafkaStopperConfiguration stopper_config = new HiveKafkaStopperConfiguration(10);


        try (KafkaDataConsumer consumer = new KafkaDataConsumer(consumer_config)) {
            try (HiveStreamer hive_streamer = new HiveStreamer(hive_streaming_config);) {
                HiveParser hive_alarms_parser = new HiveParser();
                HiveKafkaStopper stopper = new HiveKafkaStopper(stopper_config);
                while(true) {
                    List<Map<String, String>> records = consumer.GetRecords();

                    for (Map<String, String> map:records) {
                        List<String> messages = hive_alarms_parser.AlarmsRawMapToCSV(map);
                        hive_streamer.TransactMessages(messages);
                    }

                    if (stopper.IsStoppingConditionReached(records)) {
                        break;
                    }
                }
            }
        }
    }


}
