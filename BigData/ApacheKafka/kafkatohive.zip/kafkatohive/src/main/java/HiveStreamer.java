import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hive.hcatalog.streaming.*;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HiveStreamer implements Closeable {
    private HiveStreamingConfig hive_streaming_config;

    private HiveEndPoint end_point;
    private StreamingConnection connection;
    private DelimitedInputWriter csv_writer;
    private TransactionBatch transaction_batch;

    private int writes_per_commit_counter = 0;

    public HiveStreamer(HiveStreamingConfig hive_streaming_config) throws InterruptedException, StreamingException, ClassNotFoundException { //TODO, may need to be a singleton per each table
        SetHiveStreamingConfig(hive_streaming_config);

        SetHiveEndPoint();
        SetStreamingConnection();
        SetCSVWriter();
        SetTransactionBatch();

        SetNextTransaction();
    }

    private void SetHiveStreamingConfig(HiveStreamingConfig hive_streaming_config) {
        this.hive_streaming_config = hive_streaming_config;
    }

    private void SetHiveEndPoint() {
        HiveEndPoint end_point = new HiveEndPoint(this.hive_streaming_config.end_point_config.hive_metastore_uri,
                this.hive_streaming_config.end_point_config.database_name,
                this.hive_streaming_config.end_point_config.table_name,
                this.hive_streaming_config.end_point_config.partition_values);
        ReportActionWasASuccess("End point creation");

        this.end_point = end_point;
    }

    private void SetStreamingConnection() throws InterruptedException, PartitionCreationFailed, ConnectionError, InvalidPartition, ImpersonationFailed, InvalidTable {
        StreamingConnection connection = this.end_point.newConnection(this.hive_streaming_config.streaming_config.is_create_partitions,
                this.hive_streaming_config.streaming_config.custom_configuration);
        ReportActionWasASuccess("Streaming Connection creation");

        this.connection = connection;
    }

    private void SetCSVWriter() throws ClassNotFoundException, StreamingException {
        DelimitedInputWriter csv_writer = new DelimitedInputWriter(this.hive_streaming_config.csv_writer_config.table_column_names,
                this.hive_streaming_config.csv_writer_config.delimiter,
                this.end_point,
                this.hive_streaming_config.csv_writer_config.custom_configuration,
                this.hive_streaming_config.csv_writer_config.serde_separator);
        ReportActionWasASuccess("CSV writer creation");

        this.csv_writer = csv_writer;
    }

    private void SetTransactionBatch() throws InterruptedException, StreamingException {
        TransactionBatch transaction_batch = this.connection.fetchTransactionBatch(this.hive_streaming_config.transaction_config.max_commits_per_transaction,
                this.csv_writer);
        ReportActionWasASuccess("Transaction Batch creation");

        this.transaction_batch = transaction_batch;
    }

    /**
     *
     * @param csv_messages CSV String must have values ordered is the same way as they are ordered in the Hive table.
     * @throws InterruptedException
     * @throws StreamingException
     */
    public void TransactMessages(List<String> csv_messages) throws InterruptedException, StreamingException {
        ByteRecord record;
        for (String message : csv_messages) {
            record = new ByteRecord(message);
            StreamRecordToHive(record);
        }
    }

    private void StreamRecordToHive(ByteRecord record) throws StreamingException, InterruptedException {
        if (IsWritesPerTransactionReached()) {
            CommitTransaction();
            SetNextTransaction();
        }
        WriteByteRecordToHive(record.byte_record);
    }

    private boolean IsWritesPerTransactionReached() {
        int max_writes_per_commit = this.hive_streaming_config.commit_control_config.max_writes_per_commit;
        if (this.writes_per_commit_counter >= max_writes_per_commit) {
            System.out.println("Writes per transaction limit reached. (" + max_writes_per_commit + ")");
            return true;
        }
        return false;
    }

    private void WriteByteRecordToHive(byte[] byte_record) throws InterruptedException, StreamingException {
        this.transaction_batch.write(byte_record);
        this.writes_per_commit_counter++;
    }

    private void SetNextTransaction() throws StreamingException, InterruptedException {
        if (!IsReachedExpectedNumberOfCommits()) {
            this.transaction_batch.beginNextTransaction();
        } else {
            RefreshTransactionBatch();
            this.transaction_batch.beginNextTransaction();
        }
        ReportActionWasASuccess("Opening a transaction");
    }

    private boolean IsReachedExpectedNumberOfCommits() {
        int remaining_transactions = this.transaction_batch.remainingTransactions();
        if (remaining_transactions > 0) {
            System.out.println("You can still perform " + remaining_transactions + " commits.");
            return false;
        }
        System.out.println("Commits per transaction limit reached. (" + this.hive_streaming_config.transaction_config.max_commits_per_transaction + ")");
        return true;
    }

    private void RefreshTransactionBatch() throws StreamingException, InterruptedException {
        SetTransactionBatch();
    }


    public void StopStreaming() throws InterruptedException, StreamingException {
        FlushWriter();
        CommitTransaction();
        CloseTransaction();
        CloseStreamingConnection();
        ReportActionWasASuccess("Hive Streamer shutdown");
    }

    private void FlushWriter() throws StreamingIOFailure {
        csv_writer.flush();
    }

    private void CommitTransaction() throws StreamingException, InterruptedException {
        this.transaction_batch.commit();
        ResetWriteCounter();
    }

    private void ResetWriteCounter() {
        this.writes_per_commit_counter = 0;
    }

    private void CloseTransaction() throws StreamingException, InterruptedException {
        this.transaction_batch.close();
    }


    private void CloseStreamingConnection() {
        this.connection.close();
    }


    private void ReportActionWasASuccess(String message) {
        System.out.println(message + " was a success!");
    }


    @Override
    protected void finalize() throws Throwable {
        StopStreaming();
        super.finalize();
    }

    @Override
    public void close() {
        try {
            StopStreaming();
        } catch (InterruptedException | StreamingException e) {
            e.printStackTrace();
        }
    }
}

class HiveStreamingConfig {
    public HiveEndPointConfiguration end_point_config;
    public StreamingConnectionConfiguration streaming_config;
    public CSVWriterConfiguration csv_writer_config;
    public TransactionBatchConfiguration transaction_config;
    public CommitControlConfiguration commit_control_config;

    public HiveStreamingConfig(HiveEndPointConfiguration end_point_config, StreamingConnectionConfiguration streaming_config, CSVWriterConfiguration csv_writer_config, TransactionBatchConfiguration transaction_config, CommitControlConfiguration commit_control_config) {
        this.end_point_config = end_point_config;
        this.streaming_config = streaming_config;
        this.csv_writer_config = csv_writer_config;
        this.transaction_config = transaction_config;
        this.commit_control_config = commit_control_config;
    }
}

class HiveEndPointConfiguration {
    public String hive_metastore_uri;
    public String database_name; //in beeline, TABLE_SCHEM; in Ambari at the top of Hive 2.0 View
    public String table_name;
    public List<String> partition_values; //specify static table partitions; can be null

    public HiveEndPointConfiguration(String hive_metastore_uri, String database_name, String table_name, List<String> partition_values){
        this.hive_metastore_uri = hive_metastore_uri;
        this.database_name = database_name;
        this.table_name = table_name;
        this.partition_values = partition_values;
    }
}

class StreamingConnectionConfiguration {
    public boolean is_create_partitions; //can partitions be create if they do not exist
    public HiveConf custom_configuration; //custom Hive configuration object; can be null

    public StreamingConnectionConfiguration(boolean is_create_partitions, HiveConf custom_configuration) {
        this.is_create_partitions = is_create_partitions;
        this.custom_configuration = custom_configuration;
    }
}

class CSVWriterConfiguration {
    public String[] table_column_names;
    public String delimiter; //CSV delimiter
    public HiveConf custom_configuration; //custom Hive configuration object; can be null
    public char serde_separator; //separator for encoding data fed into LazySimpleSerde

    public CSVWriterConfiguration(String[] table_column_names, String delimiter, HiveConf custom_configuration, char serde_separator) {
        this.table_column_names = table_column_names;
        this.delimiter = delimiter;
        this.custom_configuration = custom_configuration;
        this.serde_separator = serde_separator;
    }
}

class TransactionBatchConfiguration{
    public int max_commits_per_transaction;

    public TransactionBatchConfiguration(int expected_number_of_transactions) {
        this.max_commits_per_transaction = expected_number_of_transactions;
    }
}

class CommitControlConfiguration {
    public int max_writes_per_commit;

    public CommitControlConfiguration(int max_writes_per_commit) {
        this.max_writes_per_commit = max_writes_per_commit;
    }
}

class ByteRecord{
    public String string_record;
    public byte[] byte_record;

    public ByteRecord(String record) {
        this.string_record = record;
        this.byte_record = TransformStringToBytes(record);
    }

    private byte[] TransformStringToBytes(String string){
        return string.getBytes();
    }
}