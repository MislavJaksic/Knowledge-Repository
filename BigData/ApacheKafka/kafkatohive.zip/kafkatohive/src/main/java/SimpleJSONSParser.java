import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;

public class SimpleJSONSParser {

    public static ArrayList<Map<String, String>> JSONStringsToMap (ArrayList<String> json_strings) throws JSONException {
        ArrayList<Map<String, String>> parsed_strings = new ArrayList<>();
        for (String string:json_strings) {
            Map<String, String> data = SimpleJSONSParser.JSONStringToMap(string);
            parsed_strings.add(data);
        }

        return parsed_strings;
    }

    public static Map<String, String> JSONStringToMap(String JSON_string) throws JSONException {
        Map<String, String> data = new HashMap<>();
        JSONObject JSON_object = new JSONObject(JSON_string);

        Iterator keys = JSON_object.keys();
        for (Iterator it = keys; it.hasNext(); ) {
            String key = (String) it.next();
            String value = JSON_object.getString(key);

            data.put(key, value);
        }

        return data;
    }
}
