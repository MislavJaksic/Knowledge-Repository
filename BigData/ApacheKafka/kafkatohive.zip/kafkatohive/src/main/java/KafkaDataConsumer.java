import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import java.io.Closeable;
import java.util.*;

/**
 * KafkaConsumer sets the required configuration, subscribes to topics and lets users get records from the topic.
 * Implements Closable which means try-with-resources will automatically close the KafkaConsumer.
 */
public class KafkaDataConsumer implements Closeable {
    private KafkaDataConsumerConfiguration config;
    private KafkaConsumer<String, String> consumer;

    /**
     *
     * @param config Send configuration parameters, topics to which it should subscribe and polling timeout duration.
     */
    public KafkaDataConsumer(KafkaDataConsumerConfiguration config) {
        SetConsumerConfig(config);

        SetConsumer();
        SubscribeToTopics();
    }

    private void SetConsumerConfig(KafkaDataConsumerConfiguration config){
        this.config = config;
    }

    private void SetConsumer() {
        Properties consumer_properties = CreateConsumerProperties();
        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(consumer_properties);

        this.consumer = consumer;
    }

    private Properties CreateConsumerProperties() {
        Properties consumer_properties = new Properties();
        consumer_properties.put("key.deserializer", this.config.key_deserializer);
        consumer_properties.put("value.deserializer", this.config.value_deserializer);
        consumer_properties.put("bootstrap.servers", this.config.bootstrap_servers);
        consumer_properties.put("group.id", this.config.group_id);

        return consumer_properties;
    }

    private void SubscribeToTopics() {
        this.consumer.subscribe(this.config.topics);
    }


    /**
     *
     * @return Data from the subscribed topics and partitions.
     */
    public List<Map<String, String>> GetRecords() {
        ConsumerRecords<String, String> records = GetJSONRecordsFromKafka();
        List<String> values = ExtractValues(records);

        List<Map<String, String>> parsed_records = JSONParser.FlatJSONToMap(values);

        return parsed_records;
    }

    /**
     *
     * @return Get maps from a list of subscribed topics and partitions. Can return an empty maps container.
     */
    private ConsumerRecords<String, String> GetJSONRecordsFromKafka() {
        ConsumerRecords<String, String> records = this.consumer.poll(this.config.poll_timeout_milliseconds);

        return records;
    }

    /**
     *
     * @param records Extract values from Kafka ConsumerRecords.
     * @return Values.
     */
    private List<String> ExtractValues(ConsumerRecords<String, String> records){
        ArrayList<String> strings = new ArrayList<>();
        for (ConsumerRecord<String, String> record:records) {
            strings.add(record.value());
        }
        return strings;
    }


    @Override
    public void close() {
        StopConsumer();
    }

    @Override
    protected void finalize() throws Throwable {
        StopConsumer();
        super.finalize();
    }

    public void StopConsumer() {
        consumer.close();
        System.out.println("Consumer closed gracefully.");
    }
}

/**
 * See http://kafka.apache.org/documentation/#consumerconfigs
 */
class KafkaDataConsumerConfiguration {
    /* Required and encouraged */
    public String key_deserializer;
    public String value_deserializer;
    public List<String> bootstrap_servers;
    public String group_id;

    public List<String> topics;
    public long poll_timeout_milliseconds;

    /* Optional */
    public String auto_offset_reset = "latest";
    public String enable_auto_commit = "true";

    public KafkaDataConsumerConfiguration(String key_deserializer, String value_deserializer, List<String> bootstrap_servers, String group_id, List<String> topics, long poll_timeout) {
        this.key_deserializer = key_deserializer;
        this.value_deserializer = value_deserializer;
        this.bootstrap_servers = bootstrap_servers;
        this.group_id = group_id;
        this.topics = topics;
        this.poll_timeout_milliseconds = poll_timeout;
    }

    public KafkaDataConsumerConfiguration(String key_deserializer, String value_deserializer, List<String> bootstrap_servers, String group_id, List<String> topics, long poll_timeout_miliseconds, String auto_offset_reset, String enable_auto_commit) {
        this.key_deserializer = key_deserializer;
        this.value_deserializer = value_deserializer;
        this.bootstrap_servers = bootstrap_servers;
        this.group_id = group_id;
        this.topics = topics;
        this.poll_timeout_milliseconds = poll_timeout_miliseconds;
        this.auto_offset_reset = auto_offset_reset;
        this.enable_auto_commit = enable_auto_commit;
    }
}
