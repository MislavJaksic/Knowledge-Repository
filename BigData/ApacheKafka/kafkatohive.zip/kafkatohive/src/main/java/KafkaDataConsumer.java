import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import java.util.*;

import org.json.JSONException;

public class KafkaDataConsumer {
    private KafkaDataConsumerConfiguration config = null;
    private KafkaConsumer<String, String> consumer = null;

    public KafkaDataConsumer(KafkaDataConsumerConfiguration config) {
        SetConsumerConfig(config);
        RegisterShutdownHook();

        SetConsumer();
        SubscribeToTopics();
    }

    private void SetConsumerConfig(KafkaDataConsumerConfiguration config){
        this.config = config;
    }

    private void RegisterShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            StopConsumer();
        }));
    }

    private void SetConsumer() {
        Properties consumer_properties = CreateConsumerProperties();
        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(consumer_properties);
        this.consumer = consumer;
    }

    private Properties CreateConsumerProperties() {
        Properties consumer_properties = new Properties();
        consumer_properties.put("key.deserializer", this.config.key_deserializer);
        consumer_properties.put("value.deserializer", this.config.value_deserializer);
        consumer_properties.put("bootstrap.servers", this.config.bootstrap_servers);
        consumer_properties.put("group.id", this.config.group_id);
        return consumer_properties;
    }


    private void SubscribeToTopics() {
        this.consumer.subscribe(this.config.topics);
    }


    public ArrayList<Map<String, String>> GetRecords() throws JSONException {
        ConsumerRecords<String, String> raw_records = ReadRecordsFromKafka();

        ArrayList<String> string_records = TransformRecordsToStrings(raw_records);
        ArrayList<Map<String, String>> parsed_records = SimpleJSONSParser.JSONStringsToMap(string_records);

        return parsed_records;
    }

    private ConsumerRecords<String, String> ReadRecordsFromKafka() {
        ConsumerRecords<String, String> records = this.consumer.poll(this.config.poll_timeout_milliseconds);

        return records;
    }

    private ArrayList<String> TransformRecordsToStrings(ConsumerRecords<String, String> records){
        ArrayList<String> string_records = new ArrayList<>();
        for (ConsumerRecord<String, String> record:records) {
            string_records.add(record.value());
        }

        return string_records;
    }


    public void StopConsumer() {
        consumer.close();
        System.out.println("Consumer shutdown was a success!");
    }



    @Override
    protected void finalize() throws Throwable {
        StopConsumer();
        super.finalize();
    }
}

class KafkaDataConsumerConfiguration {
    /* http://kafka.apache.org/documentation/#consumerconfigs */
    /* Required */
    public String key_deserializer;
    public String value_deserializer;
    public ArrayList<String> bootstrap_servers;
    public String group_id;

    public ArrayList<String> topics;
    public long poll_timeout_milliseconds;

    /* Optional */
    public String auto_offset_reset = "latest";
    public String enable_auto_commit = "true";

    public KafkaDataConsumerConfiguration(String key_deserializer, String value_deserializer, ArrayList<String> bootstrap_servers, String group_id, ArrayList<String> topics, long poll_timeout) {
        this.key_deserializer = key_deserializer;
        this.value_deserializer = value_deserializer;
        this.bootstrap_servers = bootstrap_servers;
        this.group_id = group_id;
        this.topics = topics;
        this.poll_timeout_milliseconds = poll_timeout;
    }

    public KafkaDataConsumerConfiguration(String key_deserializer, String value_deserializer, ArrayList<String> bootstrap_servers, String group_id, ArrayList<String> topics, long poll_timeout_miliseconds, String auto_offset_reset, String enable_auto_commit) {
        this.key_deserializer = key_deserializer;
        this.value_deserializer = value_deserializer;
        this.bootstrap_servers = bootstrap_servers;
        this.group_id = group_id;
        this.topics = topics;
        this.poll_timeout_milliseconds = poll_timeout_miliseconds;
        this.auto_offset_reset = auto_offset_reset;
        this.enable_auto_commit = enable_auto_commit;
    }
}
