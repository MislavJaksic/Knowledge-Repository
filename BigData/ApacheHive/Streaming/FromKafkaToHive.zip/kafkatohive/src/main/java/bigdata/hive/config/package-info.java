/**
 * Contains all classes required for properly configuring Apache Hive classes.
 */
package bigdata.hive.config;