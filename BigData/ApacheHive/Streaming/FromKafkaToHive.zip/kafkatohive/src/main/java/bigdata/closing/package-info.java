/**
 * Contains all classes required for tracking data which will decide when to close a program gracefully.
 */
package bigdata.closing;