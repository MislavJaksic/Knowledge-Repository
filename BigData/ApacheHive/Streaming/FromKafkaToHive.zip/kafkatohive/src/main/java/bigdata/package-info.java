/**
 * Contains all packages required for constructing a data pipeline shown below.
 * Data pipeline: DATA SOURCE ---> Apache Kafka ---> Apache Hive <---> Apache Spark
 */
package bigdata;