/**
 * Contains all classes required for transporting data to and from Apache Kafka.
 * @see <a href="https://kafka.apache.org/">Apache Kafka Website</a>
 */
package bigdata.kafka;