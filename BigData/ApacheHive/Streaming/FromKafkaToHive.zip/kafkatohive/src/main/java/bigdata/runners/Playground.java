package bigdata.runners;

import java.util.List;

import bigdata.hive.config.MetaStoreClientWrapperConfiguration;
import bigdata.hive.config.TableInDatabase;
import bigdata.hive.metastore.MetaStoreClientWrapper;

/**
 * For playing around with different classes, to see if they work, for manually checking their output.
 */
public class Playground {

    public static void main(String[] args) {
        MetaStoreClientWrapperConfiguration config = new MetaStoreClientWrapperConfiguration("thrift://sandbox-hdp.hortonworks.com:9083");
        MetaStoreClientWrapper metastore = new MetaStoreClientWrapper(config);
        TableInDatabase table_in_database = new TableInDatabase("default", "unpartitioned_alarms_raw");
        List<String> columns = metastore.GetNamesOfColumns(table_in_database);
        System.out.println(columns.toString());
    }
}
