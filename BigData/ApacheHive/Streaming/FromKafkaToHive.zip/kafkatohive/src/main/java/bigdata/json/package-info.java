/**
 * Contains all classes required for parsing JSON constructs into Java data structures (collections).
 */
package bigdata.json;