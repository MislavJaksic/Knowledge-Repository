/**
 * Contains all classes required for interacting with Apache Hive.
 * @see <a href="https://hive.apache.org/">Apache Hive Website</a>
 */
package bigdata.hive;