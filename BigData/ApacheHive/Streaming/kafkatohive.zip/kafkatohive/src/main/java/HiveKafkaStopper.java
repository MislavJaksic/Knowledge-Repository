import java.util.List;
import java.util.Map;

public class HiveKafkaStopper {
    private int empty_counter = 0;
    private int max_empty;

    public HiveKafkaStopper(HiveKafkaStopperConfiguration config) {
        SetConfig(config);
    }

    private void SetConfig(HiveKafkaStopperConfiguration config) {
        this.max_empty = config.max_empty;
    }

    public boolean IsStoppingConditionReached(List<Map<String, String>> map) {
        if (IsEmptyManyTimes(map)){
            return true;
        }
        return false;
    }

    private boolean IsEmptyManyTimes(List<Map<String, String>> map) {
        if (map.isEmpty()){
            empty_counter++;
            if (empty_counter > this.max_empty){
                return true;
            }
        } else {
            empty_counter = 0;
        };
        return false;
    }
}

class HiveKafkaStopperConfiguration {
    public int max_empty;

    public HiveKafkaStopperConfiguration(int max_empty) {
        this.max_empty = max_empty;
    }
}