import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.*;

/**
 * A JSON string to data structure parser.
 */
public class JSONParser {

    /**
     * Transforms multiple JSON strings. See FlatJSONToMap(String string).
     * @param JSON_strings JSON strings.
     * @return Maps.
     */
    public static List<Map<String, String>> FlatJSONToMap (List<String> JSON_strings) {
        ArrayList<Map<String, String>> parsed_strings = new ArrayList<>();
        for (String string:JSON_strings) {
            Map<String, String> data = JSONParser.FlatJSONToMap(string);
            parsed_strings.add(data);
        }
        return parsed_strings;
    }

    /**
     * Transforms a "flat" JSON string into a Map.
     * @param JSON_string An example of a "flat" JSON string: "{"key_one": "value_one", "key_two": "value_two", ...}"
     * @return The example produces a Map: {key_one=value_one, key_two=value_two, ...}
     */
    public static Map<String, String> FlatJSONToMap(String JSON_string) {
        Gson json_parser = new Gson();
        Type map_template = JSONParser.GetMapTemplate();

        HashMap<String, String> JSON_map = json_parser.fromJson(JSON_string, map_template);
        return JSON_map;
    }

    /**
     * See https://github.com/google/gson/blob/master/UserGuide.md
     * @return A template used by Gson.
     */
    private static Type GetMapTemplate() {
        return new TypeToken<HashMap<String, String>>(){}.getType();
    }
}
