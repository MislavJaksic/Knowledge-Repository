import java.util.List;

public class Playground {

    public static void main(String[] args) {
        HiveMetaStoreClientWrapperConfiguration config = new HiveMetaStoreClientWrapperConfiguration("thrift://sandbox-hdp.hortonworks.com:9083");
        HiveMetaStoreClientWrapper metastore = new HiveMetaStoreClientWrapper(config);
        List<String> columns = metastore.GetNamesOfColumnsInDatabaseOfTable("default", "unpartitioned_alarms_raw");
        System.out.println(columns.toString());
    }
}
