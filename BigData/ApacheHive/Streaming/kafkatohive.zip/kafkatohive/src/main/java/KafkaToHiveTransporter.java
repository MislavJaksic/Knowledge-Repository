import org.apache.hadoop.hive.metastore.HiveMetaStore;
import org.apache.hive.hcatalog.streaming.StreamingException;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Can move around 3 300 000 bytes from Kafka to Hive.
 */
public class KafkaToHiveTransporter { //TODO, cleanup; move properties/configs to a file; automate coupled config discovery

    public static void main(String[] args) {
        List<String> bootstrap_servers = new ArrayList<>();
        bootstrap_servers.add("192.168.50.56:9094");
        List<String> topics = new ArrayList<>();
        topics.add("alarms");
        KafkaDataConsumerConfiguration consumer_config = new KafkaDataConsumerConfiguration(StringDeserializer.class.getName(),
                StringDeserializer.class.getName(),
                bootstrap_servers,
                "hive_consumers",
                topics,
                2000);


        HiveEndPointConfiguration end_point_config = new HiveEndPointConfiguration("thrift://sandbox-hdp.hortonworks.com:9083",
                "default",
                "unpartitioned_alarms_raw",
                null);
        StreamingConnectionConfiguration streaming_connection_config = new StreamingConnectionConfiguration(true,
                null);
        CSVWriterConfiguration csv_writer_config = new CSVWriterConfiguration(",",
                null,
                ',');
        TransactionBatchConfiguration transaction_batch_config = new TransactionBatchConfiguration(200);
        CommitControlConfiguration commit_control_config = new CommitControlConfiguration(10000);
        HiveStreamingConfiguration hive_streaming_config = new HiveStreamingConfiguration(end_point_config,
                streaming_connection_config,
                csv_writer_config,
                transaction_batch_config,
                commit_control_config);

        HiveKafkaStopperConfiguration stopper_config = new HiveKafkaStopperConfiguration(10);


        try (KafkaDataConsumer consumer = new KafkaDataConsumer(consumer_config)) {
            try (HiveStreamer hive_streamer = new HiveStreamer(hive_streaming_config);) {
                HiveParser hive_alarms_parser = new HiveParser();
                HiveKafkaStopper stopper = new HiveKafkaStopper(stopper_config);
                while(true) {
                    List<Map<String, String>> records = consumer.GetJSONRecords();

                    for (Map<String, String> map:records) {
                        List<String> messages = hive_alarms_parser.AlarmsRawToCSV(map);
                        hive_streamer.TransactMessages(messages);
                    }

                    if (stopper.IsStoppingConditionReached(records)) {
                        break;
                    }
                }
            }
        }
    }


}
