import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hive.hcatalog.streaming.*;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * For streaming data into an (unpartitioned) Hive table without having to worry about how transactions work.
 * Control how many times you can commit data to a single transaction and how many times you can write data
 * into the table before committing data.
 */
public class HiveStreamer implements Closeable {
    private static final int exception_exit_code = -4;

    private HiveStreamingConfiguration hive_streaming_config;

    private HiveEndPoint end_point;
    private StreamingConnection connection;
    private DelimitedInputWriter csv_writer;
    private TransactionBatch transaction_batch;

    private int writes_per_commit_counter = 0;

    public HiveStreamer(HiveStreamingConfiguration hive_streaming_config) { //TODO, may need to be a singleton per each table
        SetHiveStreamingConfiguration(hive_streaming_config);

        SetAllStreamingInstances();

        OpenNewTransaction();
    }

    private void SetHiveStreamingConfiguration(HiveStreamingConfiguration hive_streaming_config) {
        this.hive_streaming_config = hive_streaming_config;
    }

    private void SetAllStreamingInstances() {
        SetHiveEndPoint();
        SetStreamingConnection();
        SetCSVWriter();
        SetTransactionBatch();
    }

    private void SetHiveEndPoint() {
        HiveEndPoint end_point = new HiveEndPoint(this.hive_streaming_config.end_point_config.hive_metastore_uri,
                this.hive_streaming_config.end_point_config.database_name,
                this.hive_streaming_config.end_point_config.table_name,
                this.hive_streaming_config.end_point_config.partition_values);

        this.end_point = end_point;
        ReportActionWasASuccess("End point creation");
    }

    /**
     * Attempt to create a Streaming Connection.
     * If you cannot, shutdown.
     */
    private void SetStreamingConnection() {
        try {
            StreamingConnection connection = this.end_point.newConnection(this.hive_streaming_config.streaming_config.is_create_partitions,
                    this.hive_streaming_config.streaming_config.custom_configuration);

            this.connection = connection;
            ReportActionWasASuccess("Streaming Connection creation");

        } catch (ConnectionError | InterruptedException | ImpersonationFailed | PartitionCreationFailed | InvalidTable | InvalidPartition connectionError) {
            connectionError.printStackTrace();
            ShutDownAfterException();
        }
    }

    /**
     * Attempt to create a CSV Writer.
     * If you cannot, cleanup and shutdown.
     */
    private void SetCSVWriter() {
        try {
            String[] table_column_names = GetTableColumnNames();
            DelimitedInputWriter csv_writer = new DelimitedInputWriter(table_column_names,
                    this.hive_streaming_config.csv_writer_config.delimiter,
                    this.end_point,
                    this.hive_streaming_config.csv_writer_config.custom_configuration,
                    this.hive_streaming_config.csv_writer_config.serde_separator);

            this.csv_writer = csv_writer;
            ReportActionWasASuccess("CSV writer creation");

        } catch (ClassNotFoundException | StreamingException e) {
            e.printStackTrace();
            CloseStreamingConnection();
            ShutDownAfterException();
        }
    }

    private String[] GetTableColumnNames() {
        HiveMetaStoreClientWrapperConfiguration config = new HiveMetaStoreClientWrapperConfiguration(this.hive_streaming_config.end_point_config.hive_metastore_uri);
        HiveMetaStoreClientWrapper metastore = new HiveMetaStoreClientWrapper(config);

        List<String> table_column_names = metastore.GetNamesOfColumnsInDatabaseOfTable(this.hive_streaming_config.end_point_config.database_name,
                this.hive_streaming_config.end_point_config.table_name);

        return (String[]) table_column_names.toArray();
    }

    /**
     * Attempt to create a Transaction Batch.
     * If you cannot, cleanup and shutdown.
     */
    private void SetTransactionBatch() {
        try {
            TransactionBatch transaction_batch = this.connection.fetchTransactionBatch(this.hive_streaming_config.transaction_config.max_commits_per_transaction,
                    this.csv_writer);

            this.transaction_batch = transaction_batch;
            ReportActionWasASuccess("Transaction Batch creation");

        } catch (StreamingException | InterruptedException e) {
            e.printStackTrace();
            CloseStreamingConnection();
            ShutDownAfterException();
        }
    }



    /**
     *
     * @param csv_messages CSV String must have values ordered is the same way as they are ordered in "CSVWriterConfiguration.table_column_names".
     */
    public void TransactMessages(List<String> csv_messages) {
        Record record;
        for (String message : csv_messages) {
            record = new Record(message);
            StreamRecordToHive(record);
        }
    }

    private void StreamRecordToHive(Record record) {
        if (IsWritesPerTransactionReached()) {
            CommitTransaction();
            OpenNewTransaction();
        }
        WriteRecordToHive(record);
    }

    private boolean IsWritesPerTransactionReached() {
        int max_writes_per_commit = this.hive_streaming_config.commit_control_config.max_writes_per_commit;
        if (this.writes_per_commit_counter >= max_writes_per_commit) {
            System.out.println("Writes per transaction limit reached. (" + max_writes_per_commit + ")");
            return true;
        }
        return false;
    }


    private void ResetWriteCounter() {
        this.writes_per_commit_counter = 0;
    }


    private void OpenNewTransaction() {
        if (!IsReachedExpectedNumberOfCommits()) {
            BeginNextTransactionInTransactionBatch();
        } else {
            RefreshTransactionBatch();
            BeginNextTransactionInTransactionBatch();
        }
        ReportActionWasASuccess("Opening a transaction");
    }

    private boolean IsReachedExpectedNumberOfCommits() {
        if (GetRemainingCommits() > 0) {
            System.out.println("You can still perform " + GetRemainingCommits() + " commits.");
            return false;
        }
        System.out.println("Commits per transaction limit reached. (" + this.hive_streaming_config.transaction_config.max_commits_per_transaction + ")");
        return true;
    }

    /**
     *
     * @return How many times you can still perform .commit() on the current Transaction Batch.
     */
    private int GetRemainingCommits() {
        return this.transaction_batch.remainingTransactions();
    }

    /**
     * Attempt to begin a new transaction in Transaction Batch.
     * If you cannot, stop streaming and shutdown.
     */
    private void BeginNextTransactionInTransactionBatch() {
        try {
            this.transaction_batch.beginNextTransaction();
        } catch (StreamingException | InterruptedException e) {
            e.printStackTrace();
            StopStreamingAndShutDown();
        }
    }

    private void RefreshTransactionBatch() {
        SetTransactionBatch();
    }


    private void WriteRecordToHive(Record record) {
        WriteToHive(record);
        IncrementWritesPerCommit();
    }

    /**
     * Attempt to write to Hive.
     * If you cannot, stop streaming and shutdown.
     * @param record Simple record.
     */
    private void WriteToHive(Record record) {
        try {
            this.transaction_batch.write(record.byte_record);
        } catch (StreamingException | InterruptedException e) {
            e.printStackTrace();
            StopStreamingAndShutDown();
        }
    }

    private void IncrementWritesPerCommit() {
        this.writes_per_commit_counter++;
    }



    private void StopStreamingAndShutDown() {
        StopStreaming();
        ShutDownAfterException();
    }

    /**
     * Attempt to stop streaming.
     * If you cannot, the function will attempt to stop as much as it can.
     */
    public void StopStreaming() {
        FlushWriter();
        CommitTransaction();
        CloseAll();
        ReportActionWasASuccess("Hive Streamer shutdown");
    }

    /**
     * Attempt to flush the writer.
     */
    private void FlushWriter() {
        try {
            csv_writer.flush();
        } catch (StreamingIOFailure streamingIOFailure) {
            streamingIOFailure.printStackTrace();
        }
    }

    /**
     * Attempt to commit a transaction.
     * If you cannot, close what you can and then shutdown.
     */
    private void CommitTransaction() {
        try {
            this.transaction_batch.commit();
            ResetWriteCounter();
        } catch (StreamingException | InterruptedException e) {
            e.printStackTrace();
            CloseAll();
            ShutDownAfterException();
        }
    }


    /**
     * Close both the Transaction Bach and the Streaming Connection.
     */
    private void CloseAll() {
        CloseTransaction();
        CloseStreamingConnection();
    }

    /**
     * Attempt to close the Transaction Batch.
     */
    private void CloseTransaction() {
        try {
            this.transaction_batch.close();
        } catch (StreamingException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Close the Streaming Connection.
     */
    private void CloseStreamingConnection() {
        this.connection.close();
    }


    private void ReportActionWasASuccess(String message) {
        System.out.println(message + " was a success!");
    }

    private void ShutDownAfterException() {
        System.out.println("Shutting down after an exception.");
        System.exit(HiveStreamer.exception_exit_code);
    }


    @Override
    protected void finalize() throws Throwable {
        StopStreaming();
        super.finalize();
    }

    @Override
    public void close() {
        StopStreaming();
    }
}

class HiveStreamingConfiguration {
    public HiveEndPointConfiguration end_point_config;
    public StreamingConnectionConfiguration streaming_config;
    public CSVWriterConfiguration csv_writer_config;
    public TransactionBatchConfiguration transaction_config;
    public CommitControlConfiguration commit_control_config;

    public HiveStreamingConfiguration(HiveEndPointConfiguration end_point_config, StreamingConnectionConfiguration streaming_config, CSVWriterConfiguration csv_writer_config, TransactionBatchConfiguration transaction_config, CommitControlConfiguration commit_control_config) {
        this.end_point_config = end_point_config;
        this.streaming_config = streaming_config;
        this.csv_writer_config = csv_writer_config;
        this.transaction_config = transaction_config;
        this.commit_control_config = commit_control_config;
    }
}

class HiveEndPointConfiguration {
    public String hive_metastore_uri;
    public String database_name; //in beeline, TABLE_SCHEM; in Ambari at the top of Hive 2.0 View
    public String table_name;
    public List<String> partition_values; //specify static table partitions; can be null

    public HiveEndPointConfiguration(String hive_metastore_uri, String database_name, String table_name, List<String> partition_values){
        this.hive_metastore_uri = hive_metastore_uri;
        this.database_name = database_name;
        this.table_name = table_name;
        this.partition_values = partition_values;
    }
}

class StreamingConnectionConfiguration {
    public boolean is_create_partitions; //can partitions be create if they do not exist
    public HiveConf custom_configuration; //custom Hive configuration object; can be null

    public StreamingConnectionConfiguration(boolean is_create_partitions, HiveConf custom_configuration) {
        this.is_create_partitions = is_create_partitions;
        this.custom_configuration = custom_configuration;
    }
}

class CSVWriterConfiguration {
    public String delimiter; //CSV delimiter
    public HiveConf custom_configuration; //custom Hive configuration object; can be null
    public char serde_separator; //separator for encoding data fed into LazySimpleSerde

    public CSVWriterConfiguration(String delimiter, HiveConf custom_configuration, char serde_separator) {
        this.delimiter = delimiter;
        this.custom_configuration = custom_configuration;
        this.serde_separator = serde_separator;
    }
}

class TransactionBatchConfiguration{
    public int max_commits_per_transaction;

    public TransactionBatchConfiguration(int expected_number_of_transactions) {
        this.max_commits_per_transaction = expected_number_of_transactions;
    }
}

class CommitControlConfiguration {
    public int max_writes_per_commit;

    public CommitControlConfiguration(int max_writes_per_commit) {
        this.max_writes_per_commit = max_writes_per_commit;
    }
}

class Record {
    public String string_record;
    public byte[] byte_record;

    public Record(String record) {
        this.string_record = record;
        this.byte_record = TransformStringToBytes(record);
    }

    private byte[] TransformStringToBytes(String string){
        return string.getBytes();
    }
}