import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.hive.metastore.HiveMetaStoreClient;
import org.apache.hadoop.hive.metastore.api.FieldSchema;
import org.apache.hadoop.hive.metastore.api.MetaException;
import org.apache.thrift.TException;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.List;

/**
 * For talking to the Hive metastore.
 * The metastore is Hive's metadata repository.
 * Metadata is all the data that is not part of a table row.
 */
public class HiveMetaStoreClientWrapper implements Closeable {
    private HiveMetaStoreClientWrapperConfiguration config;

    private HiveMetaStoreClient metastore_client;

    public HiveMetaStoreClientWrapper(HiveMetaStoreClientWrapperConfiguration config) {
        SetConfig(config);
        SetMetastoreClient();
    }

    private void SetConfig(HiveMetaStoreClientWrapperConfiguration config) {
        this.config = config;
    }

    private void SetMetastoreClient() {
        try {
            HiveConf config = CreateHiveConfiguration();
            HiveMetaStoreClient metastore_client = new HiveMetaStoreClient(config);
            this.metastore_client = metastore_client;
        } catch (MetaException e) {
            e.printStackTrace();
        }
    }

    private HiveConf CreateHiveConfiguration() {
        HiveConf hive_configuration = new HiveConf(HiveMetaStoreClientWrapper.class);
        hive_configuration.setVar(HiveConf.ConfVars.METASTOREURIS, this.config.hive_metastore_uris);

        return hive_configuration;
    }



    /**
     *
     * @param database Hive database name.
     * @param table Hive table located in a given database.
     * @return Names of table columns.
     */
    public List<String> GetNamesOfColumnsInDatabaseOfTable(String database, String table) {
        List<FieldSchema> fields = GetFieldsInDatabaseOfTable(database, table);

        ArrayList<String> columns = new ArrayList<>();
        for (FieldSchema field:fields) {
            columns.add(field.getName());
        }
        return columns;
    }

    /**
     *
     * @param database Hive database name.
     * @param table Hive table located in a given database.
     * @return Fields which describe the table columns.
     */
    public List<FieldSchema> GetFieldsInDatabaseOfTable(String database, String table) {
        List<FieldSchema> fields = null;
        try {
            fields = this.metastore_client.getFields(database, table);
        } catch (TException e) {
            e.printStackTrace();
        }
        return fields;
    }



    @Override
    public void close() {
        this.metastore_client.close();
    }
}

class HiveMetaStoreClientWrapperConfiguration {
    public String hive_metastore_uris;

    public HiveMetaStoreClientWrapperConfiguration(String hive_metastore_uris) {
        this.hive_metastore_uris = hive_metastore_uris;
    }
}
