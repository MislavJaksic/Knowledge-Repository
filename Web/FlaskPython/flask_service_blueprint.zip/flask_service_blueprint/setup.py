from setuptools import setup

setup(name='flask_service_blueprint',
        packages=['flask_service_blueprint'],
        include_package_data=True,
        install_requires=['flask'])

#Make sure to do the following:
#export FLASK_APP=/path/to/your/flask_service_blueprint
#export FLASK_ENV=development
#
#pip install -e .
#flask run