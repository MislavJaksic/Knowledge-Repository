from flask import Flask
app = Flask(__name__)

import flask_service_blueprint.views