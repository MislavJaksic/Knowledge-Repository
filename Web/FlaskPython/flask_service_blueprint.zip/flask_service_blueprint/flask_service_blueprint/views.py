from flask_service_blueprint import app

@app.route('/')
def index():
    return 'Hello World!'