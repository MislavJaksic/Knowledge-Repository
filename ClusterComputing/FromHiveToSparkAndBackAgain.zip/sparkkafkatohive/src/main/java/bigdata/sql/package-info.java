/**
 * Contains all classes required for constructing SQL commands.
 */
package bigdata.sql;