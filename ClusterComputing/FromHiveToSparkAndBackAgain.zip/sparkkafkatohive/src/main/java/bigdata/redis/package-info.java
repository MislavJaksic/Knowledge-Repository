/**
 * Contains all classes required for interacting with Redis.
 * @see <a href="https://redis.io/">Redis Website</a>
 */
package bigdata.redis;