/**
 * Contains all classes required for interacting with Apache Spark.
 * @see <a href="https://spark.apache.org/">Apache Spark</a>
 */
package bigdata.spark;