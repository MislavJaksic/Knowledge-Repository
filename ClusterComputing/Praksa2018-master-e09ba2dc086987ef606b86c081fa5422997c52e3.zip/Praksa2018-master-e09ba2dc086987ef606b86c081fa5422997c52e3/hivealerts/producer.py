from csv import DictReader
from kafka.producer import KafkaProducer
import json
import time


def store_service_alerts(reader):
    producer = KafkaProducer(
        value_serializer=lambda m: json.dumps(m).encode('ascii'),
        bootstrap_servers=['192.168.50.56:9094']
    )
    cnt = 0
    for row in reader:
        row.pop('duration')
        start = {}
        start.update(row)
        start['time'] = start['start_time']
        start.pop('start_time')
        start.pop('end_time')
        producer.send('alarms', start)
        if 'end_time' in row and len(str(row['end_time']).strip()) > 1:
            end = {}
            end.update(row)
            end['time'] = end['end_time']
            end.pop('start_time')
            end.pop('end_time')
            end['status_code'] = 'OK'
            producer.send('alarms', end)
        cnt += 1
        if cnt % 50 == 0:
            print(f"sending row ( {cnt} ): {json.dumps(row)}")
    producer.close()


if __name__ == '__main__':
    while True:
        f = open('hivealerts/host_alerts_last_month.csv')
        reader = DictReader(f)
        store_service_alerts(reader)
        f.close()
        f = open('hivealerts/service_alerts_last_month.csv')
        reader = DictReader(f)
        store_service_alerts(reader)
        f.close()
