from redis import StrictRedis
from csv import DictReader
import json
import xlrd
import mmap
import math


def XLSDictReader(f, sheet_index=0):
    book = xlrd.open_workbook(file_contents=mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ))
    sheet = book.sheet_by_index(sheet_index)
    headers = dict((i, sheet.cell_value(0, i)) for i in range(sheet.ncols))

    for i in range(1, sheet.nrows):
        values = []
        for j in headers:
            value = sheet.cell_value(i, j)
            if isinstance(value, float):
                if math.fabs(value - int(value)) <= 1e-6:
                    value = int(value)
            values.append((headers[j], value))
        yield dict(value for value in values)


def store_values(reader, keys_format, keys, filter=lambda row: True, expire=False, expire_seconds=24 * 60 * 60):
    r = StrictRedis(host='192.168.50.56', charset="utf-8", decode_responses=True)
    for row in reader:
        if not filter(row):
            continue
        key = (keys_format % tuple([row[key] for key in keys]))
        for k in keys:
            row.pop(k)
        value = json.dumps(row)
        if expire:
            r.set(key, value, expire_seconds)
        else:
            r.set(key, value)


def inventory_filter(row):
    value = row['dnsname']
    compare_value = str(value).lower()
    if "n/a" in compare_value or "unknown" in compare_value or "error" in compare_value:
        return False
    return True


def store_inventory():
    """
    redis-> inventory:ipadresa
    {'ipadresa': '10.70.125.89', 'dnsname': 'c-platanus-du01-m2011', 'vendor': 'Mikrotik', 'productnumber': '2011UiAS-2HnD', 'tipid': '1', 'cisid': '273201', 'silocationid': '204606'}
    """
    csv_file = open('inventory/inventory ref data.csv')
    reader = DictReader(csv_file)
    store_values(reader, 'inventory:%s', ['ipadresa'], inventory_filter)
    csv_file.close()


def store_locations():
    """
    redis-> locations:locationid
    {'ciscustomerid': int, 'locationid': int, 'countryname': string, 'cityname': string, 'zip': int, 'streetname': string, 'streetnumber': int}
    """
    xls_file = open("inventory/Lokacije.xlsx")
    reader = XLSDictReader(xls_file)
    store_values(reader, "locations:%s:%s", ['ciscustomerid', 'locationid'])
    xls_file.close()


def store_customers():
    """
    redis-> customers:CUSTOMER_ID
    {'CUSTOMER_ID': '270984', 'CUSTOMER_NAME': 'HOTEL PHOENIX d.o.o.'}
    """
    xls_file = open("inventory/Korisnici.xlsx")
    reader = XLSDictReader(xls_file)
    store_values(reader, "customers:%s", ['CUSTOMER_ID'])
    xls_file.close()


if __name__ == '__main__':
    store_inventory()
    store_locations()
    store_customers()
