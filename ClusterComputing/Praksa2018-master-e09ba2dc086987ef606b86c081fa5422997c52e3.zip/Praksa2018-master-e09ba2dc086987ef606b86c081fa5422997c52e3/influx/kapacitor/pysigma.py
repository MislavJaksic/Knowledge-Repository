import math
import sys
import os
from redis import StrictRedis
from datetime import datetime, timedelta

project_root = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # 3 levels above current file
sys.path.extend([project_root])

from influx.kapacitor.udf import udf_pb2
from influx.kapacitor.udf.agent import Agent, Handler
from influx.kapacitor.utils import prepare_data
from influxdb.client import InfluxDBClient

time_value_us = {
    'us': 1, 'ms': 1e3, 's': 1e6, 'm': 60 * 1e6, 'h': 60 * 60 * 1e6, 'd': 24 * 60 * 60 * 1e6,
    'w': 7 * 24 * 60 * 60 * 1e6
}

import re

pattern = re.compile('(\d+)(us|ms|s|m|h|d|w)')


def parse_duration(duration):
    usecs = 0
    for (a, b) in re.findall(pattern, duration):
        usecs += int(a) * time_value_us[b.lower()]
    return usecs


class SigmaHandler(Handler):
    """
    Calculates sigma difference from mean based on data loaded from self._get_stats(self, point)
    """

    TIME_FIELD_NAME = 'time'

    def __init__(self, agent):
        self._agent = agent
        self._field = ''
        self._period = 'h'
        self._r = StrictRedis(host='192.168.50.56', charset="utf-8", decode_responses=True)
        self._keys = []
        self._values = []

    def info(self):
        """
        Respond with which type of edges we want/provide and any options we have.
        """
        response = udf_pb2.Response()
        # We will consume batch edges aka windows of data.
        response.info.wants = udf_pb2.STREAM
        # We will produce single points of data aka stream.
        response.info.provides = udf_pb2.STREAM

        # Here we can define options for the UDF.
        # Define which field we should process ( one of the fields in values mask )
        response.info.options['field'].valueTypes.append(udf_pb2.STRING)

        # Define keys mask for redis, last key should be time, and its period is used in calculations
        response.info.options['keys'].valueTypes.append(udf_pb2.STRING)

        # Define values mask for redis, needs to have 'time', and "field"
        response.info.options['values'].valueTypes.append(udf_pb2.STRING)

        return response

    def init(self, init_req):
        """
        Given a list of options initialize this instance of the handler
        """
        success = True
        msg = ''

        for opt in init_req.options:
            if opt.name == 'field':
                self._field = opt.values[0].stringValue
            if opt.name == 'keys':
                self._keys = [value.strip() for value in opt.values[0].stringValue.split(':')]
            if opt.name == 'values':
                self._values = [value.strip() for value in opt.values[0].stringValue.split(':')]

        if self._field == '':
            success = False
            msg += ' must supply a field name'
        if len(self._keys) < 1:
            success = False
            msg += ' must supply one or more keys for keys mask'
        else:
            period_char = self._keys[-1][-1]
            if period_char.lower() not in time_value_us:
                success = False
                msg += ' must supply time with period as last key in keys mask'
            else:
                self._period = f"1{period_char}"
        if len(self._values) < 1:
            success = False
            msg += ' must supply one or more values for values mask'
        else:
            if SigmaHandler.TIME_FIELD_NAME not in self._values:
                success = False
                msg += ' must supply %s in values mask' % SigmaHandler.TIME_FIELD_NAME
            if self._field not in self._values:
                success = False
                msg += ' must supply given field ( "%s" )  in values mask' % self._field


        response = udf_pb2.Response()
        response.init.success = success
        response.init.error = msg[1:]

        return response

    def point(self, point):

        mean, stddev = self._get_stats(point)
        value = point.fieldsDouble[self._field]

        sigma = 0.0 if stddev == 0.0 else abs(value - mean) / stddev

        response = udf_pb2.Response()
        response.point.time = point.time
        response.point.name = point.name
        response.point.group = point.group
        response.point.tags.update(point.tags)
        response.point.fieldsDouble.update(point.fieldsDouble)
        response.point.fieldsInt.update(point.fieldsInt)
        response.point.fieldsString.update(point.fieldsString)
        response.point.fieldsBool.update(point.fieldsBool)

        response.point.fieldsDouble["sigma"] = sigma
        response.point.fieldsDouble["py_mean"] = mean
        response.point.fieldsDouble["py_stddev"] = stddev
        # print(response)
        self._agent.write_response(response)

    def snapshot(self):
        response = udf_pb2.Response()
        response.snapshot.snapshot = bytes('', 'latin1')
        return response

    def restore(self, restore_req):
        response = udf_pb2.Response()
        response.restore.success = True
        response.restore.error = bytes('', 'latin1')
        return response

    def _get_stats(self, point):
        key = prepare_data(point, self._keys)
        date = datetime.utcfromtimestamp(point.time / 1e9)
        end_time = date - timedelta(microseconds=parse_duration(self._period))
        points_raw = self._r.zrange(
            key,
            0,
            -1,
            withscores=True
        )
        points = []
        for p in points_raw:
            values = dict(zip(self._values, p[0].split(':')))
            if float(values[SigmaHandler.TIME_FIELD_NAME]) / 1e9 > end_time.timestamp():
                continue  # data from current period of calculation
            points.append(float(values[self._field]))
        return _calculate_stats(points)


def _calculate_stats(points):
    sum_sq = 0.0
    mean = 0.0
    n = 0.0
    for p in points:
        mean += p
        n += 1.0
    if abs(n) - 1.0 < 1e-6:
        return mean, 0.0
    mean /= n
    for p in points:
        sum_sq += (mean - p) ** 2
    return mean, math.sqrt(sum_sq / (n - 1))


def test():
    agent = Agent()
    h = SigmaHandler(agent)

    from collections import namedtuple

    Point = namedtuple('Point',
                       ['database', 'name', 'retentionPolicy', 'tags', 'fieldsDouble', 'fieldsInt', 'fieldsString',
                        'fieldsBool', 'time', 'group'])
    point = Point("interface", "average_ifOutBits", "one_month", {'interface': '10150', 'ip': '10.140.2.211'},
                  {"average_bits": 5.8 * 1000 * 1000}, {}, {}, {}, 1532944801000000000, "g1")

    Options = namedtuple('Options', ['name', 'values'])
    init_req = namedtuple('init_req', ['options'])
    ValueString = namedtuple('ValueString', ['stringValue'])
    ValueInt = namedtuple('ValueString', ['intValue'])
    ValueDuration = namedtuple('ValueString', ['durationValue'])
    req = init_req([
        Options("field", [ValueString("average_bits")]),
        Options("keys", [ValueString("ifOutBits:ip:interface:time#DOTW:time#h"), ]),
        Options("values", [ValueString("time:average_bits"), ]),
    ])
    print(h.init(req))
    h.point(point)


def main():
    # Create an agent
    agent = Agent()

    # Create a handler and pass it an agent so it can write points
    h = SigmaHandler(agent)

    # Set the handler on the agent
    agent.handler = h

    # Anything printed to STDERR from a UDF process gets captured into the Kapacitor logs.
    sys.stderr.write("Starting agent for SigmaHandler")
    sys.stderr.flush()
    agent.start()
    agent.wait()
    sys.stderr.write("Agent finished")
    sys.stderr.flush()


if __name__ == '__main__':
    # print(parse_duration('1s2ms'))
    # test()
    main()
