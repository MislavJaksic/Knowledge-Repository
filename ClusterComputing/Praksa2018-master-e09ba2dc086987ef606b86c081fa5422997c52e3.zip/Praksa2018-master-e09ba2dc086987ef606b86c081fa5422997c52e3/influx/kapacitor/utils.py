from datetime import datetime


def _find_value(point, name):
    if name in point.fieldsDouble:
        return str(point.fieldsDouble[name])
    if name in point.fieldsInt:
        return str(point.fieldsInt[name])
    if name in point.fieldsString:
        return str(point.fieldsString[name])
    if name in point.fieldsBool:
        return str(point.fieldsBool[name])
    if name in point.tags:
        return str(point.tags[name])
    return name


def prepare_data(point, data):
    processed_names = ''
    for key in data:
        params = key.split('#')
        name = params[0].strip()
        value = ''
        if name == 'time':
            if len(params) > 1:
                param = params[1].strip()
                date = datetime.utcfromtimestamp(float(point.time / 1e9))
                if param == 'DOTW':
                    value = str(date.weekday())
                elif param.upper() == 'H':
                    value = str(date.hour)
                elif param.upper() == 'M':
                    value = str(date.minute)
                elif param.upper() == 'S':
                    value = str(date.second)
            else:
                value = str(int(point.time))
        else:
            value = str(_find_value(point, name))
        processed_names += ':%s' % value

    processed_names = processed_names[1:]
    return processed_names
