from influxdb import InfluxDBClient
from influxdb.exceptions import InfluxDBClientError
from .parser import parsed_generator
import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def store_values(client: InfluxDBClient, values: [dict], buffer_size=50):
    points = []
    for value in values:
        point = {
            'measurement': value['measurement'],
            'tags': {
                'ip': value['ip'],
                'interface': value['interface']
            },
            'time': value['timestamp'] * 10 ** 9,  # seconds to nano seconds
            'fields': {
                'value': value['value']
            }
        }
        points.append(point)
        if len(points) >= buffer_size:
            try:
                client.write_points(points, retention_policy="two_weeks")
                points = []
            except InfluxDBClientError as e:
                logging.info(e)

    if len(points) > 0:
        try:
            client.write_points(points, retention_policy="two_weeks")
        except InfluxDBClientError as e:
            logging.info(e)


if __name__ == '__main__':
    client = InfluxDBClient('192.168.50.56', '8086', 'root', 'root', 'raw')
    file = open('if_raw.dat')
    cnt = 0
    generator = parsed_generator(file)
    values = []
    while cnt < 500000:
        try:
            data = generator.__next__()
            values.append(data)
            print(json.dumps(data, indent=4))
            cnt += 1
        except StopIteration:
            break

    store_values(client, values)

    print(json.dumps([point for point in client.query('select * from "ifOutOctets"').get_points()], indent=4))

    file.close()
    client.close()
