import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.ArrayList;

public class SparkPlayground {

    public static void main(String[] args) throws InterruptedException {
        /*SparkStreamingContextConfiguration spark_stream_config = new SparkStreamingContextConfiguration("name_of_the_cluster",
                "local[2]",
                1000);

        ArrayList<String> bootstrap_servers = new ArrayList<>();
        bootstrap_servers.add("192.168.50.56:9094");
        ArrayList<String> topics = new ArrayList<>();
        topics.add("alarms");
        KafkaDataConsumerConfiguration consumer_config = new KafkaDataConsumerConfiguration(StringDeserializer.class.getName(),
                StringDeserializer.class.getName(),
                bootstrap_servers,
                "spark_playground",
                topics,
                1000,
                "earliest",
                "false");

        SparkKafka apache_spark = new SparkKafka(spark_stream_config, consumer_config);
        apache_spark.Run();*/

        SparkSessionHiveConfiguration spark_hive_config = new SparkSessionHiveConfiguration("local[2]",
                "my_little_spark_hive_app",
                "/apps/hive/warehouse",
                "thrift://sandbox-hdp.hortonworks.com:9083",
                "nonstrict");
        SparkHive spark_hive = new SparkHive(spark_hive_config);
        spark_hive.Run();
        spark_hive.Close();
    }
}
