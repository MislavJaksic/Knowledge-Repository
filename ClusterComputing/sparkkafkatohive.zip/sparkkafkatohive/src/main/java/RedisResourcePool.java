import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.io.Closeable;

/**
 * A singleton Redis resource pool which offers Redis instances.
 */
public class RedisResourcePool implements Closeable {
    public final static RedisResourcePool INSTANCE = new RedisResourcePool();

    private RedisConfiguration config;
    private JedisPool pool;

    /**
     * Part of a thread-safe singleton construction. Defeats instantiation.
     */
    public RedisResourcePool() {

    }

    /**
     *
     * @param config You can only set the resource pool configuration once.
     * @return Redis instance from a resource pool.
     */
    public Jedis GetJedisInstance(RedisConfiguration config) {
        if (this.config == null) {
            SetConfig(config);
            SetRedisPool();
        }
        return this.pool.getResource();
    }

    private void SetConfig(RedisConfiguration config) {
        this.config = config;
    }

    private void SetRedisPool() {
        JedisPool pool = new JedisPool(new JedisPoolConfig(), this.config.host);

        this.pool = pool;
    }

    @Override
    public void close() {
        this.pool.close();
    }
}

class RedisConfiguration {
    public String host;

    public RedisConfiguration(String host) {
        this.host = host;
    }
}