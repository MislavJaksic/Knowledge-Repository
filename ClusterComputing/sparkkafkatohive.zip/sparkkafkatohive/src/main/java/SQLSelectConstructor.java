public class SQLSelectConstructor {
    public static final String sql_sentinel = "-1";

    public static String ConstructSQLString(SQLStringConfiguration config) {
        String sql_string = "SELECT DISTINCT " + config.select + " FROM " + config.from;

        if (!config.where.equals(SQLSelectConstructor.getSql_sentinel())) {
            sql_string = sql_string + " WHERE " + config.where;
        }
        if (!config.group_by.equals(SQLSelectConstructor.getSql_sentinel())) {
            sql_string = sql_string + " GROUP BY " + config.group_by;
        }
        if (!config.order_by.equals(SQLSelectConstructor.getSql_sentinel())) {
            sql_string = sql_string + " ORDER BY " + config.order_by;
        }
        if (!config.limit.equals(SQLSelectConstructor.getSql_sentinel())) {
            sql_string = sql_string + " LIMIT " + config.limit;
        }

        return sql_string;
    }

    public static String getSql_sentinel() {
        return sql_sentinel;
    }
}

class SQLStringConfiguration {
    public String select;
    public String from;
    public String where;
    public String group_by;
    public String order_by;
    public String limit;

    public SQLStringConfiguration(String select, String from, String where, String group_by, String order_by, String limit) {
        this.select = select;
        this.from = from;
        this.where = where;
        this.group_by = group_by;
        this.order_by = order_by;
        this.limit = limit;
    }
}