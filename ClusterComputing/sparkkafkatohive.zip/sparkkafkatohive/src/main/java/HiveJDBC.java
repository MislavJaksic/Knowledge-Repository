import java.sql.*;

/**
 * An experimental class.
 */
public class HiveJDBC {
    private Connection hive_connection = null;
    private Statement statement = null;

    public HiveJDBC() throws ClassNotFoundException, SQLException {
        CheckDriver();
        SetHiveConnection();
        SetStatement();
    }

    private void CheckDriver() throws ClassNotFoundException {
        Class.forName("org.apache.hive.jdbc.HiveDriver");
        System.out.println("Driver found");
    }

    private void SetHiveConnection() throws SQLException {
        Connection hive_connection = DriverManager.getConnection("jdbc:hive2://localhost:10000", "queries_user_name", "");
        System.out.println("Connection created");

        this.hive_connection = hive_connection;
    }

    private void SetStatement() throws SQLException {
        Statement statement = this.hive_connection.createStatement();
        System.out.println("Statement created");

        this.statement = statement;
    }



    public void Run() throws SQLException {
        String select_columns = "ip";
        String select_table = "unpartitioned_alarms_raw";
        String sql_select = "SELECT " + select_columns + " FROM " + select_table + " GROUP BY " + select_columns;
        //sql_builder.execute(); //-> for non select commands

        ResultSet select_results = this.statement.executeQuery(sql_select);
        System.out.println("Reading results");

        while (select_results.next()) {
            System.out.println(select_results.getString(select_columns));
        }
    }

    public void CloseConnection() throws SQLException {
        hive_connection.close();
    }
}
