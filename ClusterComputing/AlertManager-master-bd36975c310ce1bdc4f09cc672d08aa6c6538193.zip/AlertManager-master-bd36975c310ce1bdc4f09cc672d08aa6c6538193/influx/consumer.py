from kafka import KafkaConsumer
from influx.storer import store_values
import json
from datetime import datetime, timedelta
from influxdb import InfluxDBClient
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def store_from_kafka(batch_size=50, seconds_to_wait=1):
    consumer = KafkaConsumer(
        'influxdb-if-raw',
        bootstrap_servers='192.168.50.56:9094',
        value_deserializer=lambda value: json.loads(value, encoding='ascii'),
        group_id='influxdb-consumers'
    )
    client = InfluxDBClient('192.168.50.56', '8086', 'root', 'root', 'raw')
    values = []
    last_commit = datetime.now()
    for record in consumer:
        data = record.value
        logging.log(logging.INFO, f"Processing message: {json.dumps(data)}")
        # values = [data]
        # store_values(client, values)
        # logging.log(logging.INFO, f"Stored values: {json.dumps(values)}")
        values.append(data)
        if len(values) > batch_size or last_commit < datetime.now() - timedelta(seconds=seconds_to_wait):
            store_values(client, values)
            logging.log(logging.INFO, f"Stored values: {json.dumps(values)}")
            last_commit = datetime.now()
            values = []
    consumer.close()
    client.close()


if __name__ == '__main__':
    store_from_kafka()
