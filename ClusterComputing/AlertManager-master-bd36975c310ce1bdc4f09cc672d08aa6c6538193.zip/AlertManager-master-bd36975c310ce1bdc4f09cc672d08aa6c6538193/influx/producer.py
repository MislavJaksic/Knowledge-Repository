from kafka import KafkaProducer
from influx.parser import continous_generator
import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def produce_to_if_raw(producer: KafkaProducer, lines, batch_size=500):
    futures = []
    for line in lines:
        futures.append(producer.send('influxdb-if-raw', line))
        # time.sleep(10 / 1000)  # 10ms
        logging.log(logging.INFO, f"Sent {line}")
        if len(futures) >= batch_size:
            for future in futures:
                future.get(timeout=10)
            futures = []

    if len(futures):
        for future in futures:
            future.get(timeout=10)


def produce_messages(path):
    producer = KafkaProducer(
        value_serializer=lambda m: json.dumps(m).encode('ascii'),
        bootstrap_servers=['192.168.50.56:9094']
    )
    # while True:
    #     try:
    generator = continous_generator(path, days_to_load=6*7)
    produce_to_if_raw(producer, generator)
    # except KeyboardInterrupt:
    #     break
    producer.close()


if __name__ == '__main__':
    produce_messages('influx/if_raw.dat')
