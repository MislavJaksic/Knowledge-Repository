#!/usr/bin/env bash
nohup /root/python/AlertManager/pythonenv/bin/python /root/python/AlertManager/main.py --task producer --path /root/python/AlertManager/influx/if_raw.dat > /tmp/producer.out &
nohup /root/python/AlertManager/pythonenv/bin/python /root/python/AlertManager/main.py --task consumer  > /tmp/consumer.out &