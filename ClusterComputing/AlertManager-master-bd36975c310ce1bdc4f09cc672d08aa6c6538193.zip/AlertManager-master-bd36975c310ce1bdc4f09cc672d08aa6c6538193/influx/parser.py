import json
from time import sleep, time
import sys
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


class FormatError(Exception):
    def __init__(self, *args: object, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)


def parse_line(line):
    line = line.strip()
    timestamp, ip, _, label, value = line.split(';')
    measure, interface = label.split('.')
    if len(value) == 0:
        raise FormatError("Wrong format. No value. %s" % line)
    return {
        'timestamp': int(timestamp),
        'ip': ip,
        'measurement': measure,
        'interface': interface,
        'value': 0.0 if len(value) == 0 else float(value)
    }


def parsed_generator(file):
    for line in file:
        try:
            yield parse_line(line)
        except FormatError as e:
            logging.exception(e)
            continue


def continous_generator(path, days_to_load=14):
    min_time = sys.maxsize
    cycle_count = 0
    cycle_length = 0
    last_timestamp = 0
    while True:
        file = open(path)
        for line in file:
            try:
                data = parse_line(line)
            except FormatError as e:
                logging.exception(e)
                continue
            timestamp = data['timestamp']

            if timestamp < min_time:
                min_time = timestamp

            diff = timestamp - min_time
            cycle_length = max(cycle_length, diff)

            timestamp = min_time + diff

            timestamp += cycle_count * cycle_length

            current_timestamp = int(time())

            if current_timestamp < timestamp:
                sleep_time = timestamp - current_timestamp + 2
                logging.info(
                    f"Current timestamp: {str(current_timestamp)},"
                    f" Data timestamp: {str(timestamp)},"
                    f" sleep time {str(sleep_time)}"
                )
                sleep(sleep_time)

            if timestamp - last_timestamp > 1 * 60 * 60 or timestamp == 1532044501 or timestamp == 1532131201:
                print(timestamp, last_timestamp, timestamp - last_timestamp)
            last_timestamp = timestamp

            if current_timestamp - timestamp - 1 * 60 * 60 * 24 * days_to_load > 0:
                continue

            data['timestamp'] = timestamp
            yield data
        cycle_count += 1
        file.close()


if __name__ == '__main__':
    print(int(time()))
    cnt = 0
    generator = continous_generator('if_raw.dat')
    for data in generator:
        print(json.dumps(data, indent=4), cnt)
        cnt += 1
