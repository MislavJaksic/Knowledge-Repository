import math
import sys
import os
import json

project_root = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # 3 levels above current file
sys.path.extend([project_root])

from influx.kapacitor.udf import udf_pb2
from influx.kapacitor.udf.agent import Agent, Handler
from influx.kapacitor.utils import prepare_data
from redis import StrictRedis
import time
from datetime import datetime, timedelta
import random


class AlertHandler(Handler):
    """
    Stores keys:values pair to redis
    """

    def __init__(self, agent):
        self._agent = agent

        self._keys = []
        self._field = ''
        self._r = StrictRedis(host='192.168.50.56', charset="utf-8", decode_responses=True)

    def info(self):
        """
        Respond with which type of edges we want/provide and any options we have.
        """
        response = udf_pb2.Response()
        # We will consume batch edges aka windows of data.
        response.info.wants = udf_pb2.STREAM
        # We will produce single points of data aka stream.
        response.info.provides = udf_pb2.STREAM

        # Here we can define options for the UDF.
        # Define which fields are used for keys
        response.info.options['keys'].valueTypes.append(udf_pb2.STRING)

        # Define which field is used for threshold calculation
        response.info.options['field'].valueTypes.append(udf_pb2.STRING)

        return response

    def init(self, init_req):
        """
        Given a list of options initialize this instance of the handler
        """
        success = True
        msg = ''

        for opt in init_req.options:
            if opt.name == 'keys':
                self._keys = [value.strip() for value in opt.values[0].stringValue.split(':')]
            if opt.name == 'field':
                self._field = opt.values[0].stringValue

        if len(self._keys) < 1:
            success = False
            msg += ' must supply names of the keys'
        if self._field == '':
            success = False
            msg += ' must supply name of the field to compare '

        response = udf_pb2.Response()
        response.init.success = success
        response.init.error = msg[1:]

        return response

    def point(self, point):

        key = prepare_data(point, self._keys)

        thresholds = self._get_thresholds(key)
        value = point.fieldsDouble[self._field]

        alerts = self._test_value(thresholds, value)

        response = udf_pb2.Response()
        response.point.time = point.time
        response.point.name = point.name
        response.point.group = point.group
        response.point.tags.update(point.tags)
        response.point.fieldsDouble.update(point.fieldsDouble)
        response.point.fieldsInt.update(point.fieldsInt)
        response.point.fieldsString.update(point.fieldsString)
        response.point.fieldsBool.update(point.fieldsBool)

        # response.point.fieldsBool.update({
        #     (key, key in alerts) for key in thresholds
        # })
        #
        # for level in thresholds:
        #     for threshold in thresholds[level]:
        #         response.point.fieldsDouble.update({
        #             ("%s_%s" % (level, threshold), thresholds[level][threshold])
        #         })

        response.point.fieldsBool.update({
            'info': 'info' in alerts,
            'warn': 'warn' in alerts,
            'crit': 'crit' in alerts
        })

        if 'info' in alerts:
            response.point.fieldsDouble.update({
                'info_low': alerts['info']['low'],
                'info_high': alerts['info']['high']
            })

        if 'warn' in alerts:
            response.point.fieldsDouble.update({
                'warn_low': alerts['warn']['low'],
                'warn_high': alerts['warn']['high']
            })

        if 'crit' in alerts:
            response.point.fieldsDouble.update({
                'crit_low': alerts['crit']['low'],
                'crit_high': alerts['crit']['high']
            })

        self._agent.write_response(response)

    def snapshot(self):
        response = udf_pb2.Response()
        response.snapshot.snapshot = bytes('', 'latin1')
        return response

    def restore(self, restore_req):
        response = udf_pb2.Response()
        response.restore.success = True
        response.restore.error = bytes('', 'latin1')
        return response

    def _get_thresholds(self, key):
        value = self._r.get('thresholds:%s' % key)
        return json.loads(value)

    def _test_value(self, thresholds, value):
        alerts = {}
        for level in thresholds:
            if value < thresholds[level]['low'] or value > thresholds[level]['high']:
                alerts[level] = {}
                alerts[level].update(thresholds[level])
        return alerts


def test():
    agent = Agent()
    h = AlertHandler(agent)

    from collections import namedtuple

    Point = namedtuple('Point',
                       ['database', 'name', 'retentionPolicy', 'tags', 'fieldsDouble', 'fieldsInt', 'fieldsString',
                        'fieldsBool', 'time', 'group'])
    point = Point("interface", "average_ifOutBits", "one_month", {'interface': '10150', 'ip': '10.140.2.211'},
                  {"average_bits": 5.9 * 1000 * 1000}, {}, {}, {}, 1532944801000000000, "g1")

    thresholds = {
        'info': {
            'low': 4.2 * 1000 * 1000,
            'high': 4.8 * 1000 * 1000
        },
        'warn': {
            'low': 3.2 * 1000 * 1000,
            'high': 5.8 * 1000 * 1000
        },
        'crit': {
            'low': 2.2 * 1000 * 1000,
            'high': 6.8 * 1000 * 1000
        }
    }

    Options = namedtuple('Options', ['name', 'values'])
    init_req = namedtuple('init_req', ['options'])
    ValueString = namedtuple('ValueString', ['stringValue'])
    ValueInt = namedtuple('ValueString', ['intValue'])
    ValueDuration = namedtuple('ValueString', ['durationValue'])
    req = init_req([
        Options("keys", [ValueString("ifOutBits:ip:interface:time#DOTW:time#H"), ]),
        Options("field", [ValueString("average_bits")]),
    ])
    print(h.init(req))
    h._r.set('thresholds:%s' % prepare_data(point, h._keys), json.dumps(thresholds))
    h.point(point)


def main():
    # Create an agent
    agent = Agent()

    # Create a handler and pass it an agent so it can write points
    h = AlertHandler(agent)

    # Set the handler on the agent
    agent.handler = h

    # Anything printed to STDERR from a UDF process gets captured into the Kapacitor logs.
    sys.stderr.write("Starting agent for AlertHandler")
    sys.stderr.flush()
    agent.start()
    agent.wait()
    sys.stderr.write("Agent finished")
    sys.stderr.flush()


if __name__ == '__main__':
    # test()
    main()
