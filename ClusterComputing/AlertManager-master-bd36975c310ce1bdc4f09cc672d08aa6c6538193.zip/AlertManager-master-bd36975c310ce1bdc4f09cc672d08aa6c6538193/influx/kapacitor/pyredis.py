import math
import sys
import os

project_root = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # 3 levels above current file
sys.path.extend([project_root])

from influx.kapacitor.udf import udf_pb2
from influx.kapacitor.udf.agent import Agent, Handler
from influx.kapacitor.utils import prepare_data
from redis import StrictRedis
import time
from datetime import datetime, timedelta
import random


class RedisHandler(Handler):
    """
    Stores keys:values pair to redis
    """

    def __init__(self, agent):
        self._agent = agent

        self._keys = []
        self._values = []
        self._dtl = -1
        self._r = StrictRedis(host='192.168.50.56', charset="utf-8", decode_responses=True)

    def info(self):
        """
        Respond with which type of edges we want/provide and any options we have.
        """
        response = udf_pb2.Response()
        # We will consume batch edges aka windows of data.
        response.info.wants = udf_pb2.STREAM
        # We will produce single points of data aka stream.
        response.info.provides = udf_pb2.STREAM

        # Here we can define options for the UDF.
        # Define which fields are used for keys
        response.info.options['keys'].valueTypes.append(udf_pb2.STRING)

        # Define which fields are used for values
        response.info.options['values'].valueTypes.append(udf_pb2.STRING)

        # Define days to live, dtl
        response.info.options['dtl'].valueTypes.append(udf_pb2.INT)

        return response

    def init(self, init_req):
        """
        Given a list of options initialize this instance of the handler
        """
        success = True
        msg = ''

        for opt in init_req.options:
            if opt.name == 'keys':
                self._keys = [value.strip() for value in opt.values[0].stringValue.split(':')]
            if opt.name == 'values':
                self._values = [value.strip() for value in opt.values[0].stringValue.split(':')]
            if opt.name == 'dtl':
                self._dtl = opt.values[0].intValue

        if self._keys == '':
            success = False
            msg += ' must supply names of the keys'
        if self._values == '':
            success = False
            msg += ' must supply names of the values'
        if self._dtl <= 0:
            success = False
            msg += ' must supply positive integer for days to live (dtl)'

        response = udf_pb2.Response()
        response.init.success = success
        response.init.error = msg[1:]

        return response

    def point(self, point):

        key = prepare_data(point, self._keys)
        value = prepare_data(point, self._values)

        self._store_to_redis(key, value, point.time / 1e9 + self._dtl * 24 * 60 * 60)

        redis_response = 0

        response = udf_pb2.Response()
        response.point.time = point.time
        response.point.name = point.name
        response.point.group = point.group
        response.point.tags.update(point.tags)
        response.point.fieldsDouble.update(point.fieldsDouble)
        response.point.fieldsInt.update(point.fieldsInt)
        response.point.fieldsString.update(point.fieldsString)
        response.point.fieldsBool.update(point.fieldsBool)

        response.point.fieldsDouble["redis_response"] = redis_response

        # print(response)
        self._agent.write_response(response)

    def snapshot(self):
        response = udf_pb2.Response()
        response.snapshot.snapshot = bytes('', 'latin1')
        return response

    def restore(self, restore_req):
        response = udf_pb2.Response()
        response.restore.success = True
        response.restore.error = bytes('', 'latin1')
        return response

    def _store_to_redis(self, key, value, expiration_epoch):
        set_name = key
        # print(set_name)
        status = self._r.zadd(set_name, expiration_epoch, value)
        # print(float(time.time()))
        self._r.zremrangebyscore(set_name, '-inf', time.time())
        # my_set = self._r.zrange(set_name, 0, -1, withscores=True)
        # print(my_set)
        return status


def test():
    agent = Agent()
    h = RedisHandler(agent)

    from collections import namedtuple

    Point = namedtuple('Point',
                       ['database', 'name', 'retentionPolicy', 'tags', 'fieldsDouble', 'fieldsInt', 'fieldsString',
                        'fieldsBool', 'time', 'group'])
    point = Point("interface", "average_ifOutBits", "one_month", {'interface': '10150', 'ip': '10.140.2.211'},
                  {"average_bits": 5.9 * 1000 * 1000}, {}, {}, {}, 1532944801000000000, "g1")

    Options = namedtuple('Options', ['name', 'values'])
    init_req = namedtuple('init_req', ['options'])
    ValueString = namedtuple('ValueString', ['stringValue'])
    ValueInt = namedtuple('ValueString', ['intValue'])
    ValueDuration = namedtuple('ValueString', ['durationValue'])
    req = init_req([
        Options("keys", [ValueString("ifOutBits:ip:interface:time#DOTW:time#H"), ]),
        Options("values", [ValueString("time:average_bits"), ]),
        Options("dtl", [ValueInt(14), ]),
    ])
    print(h.init(req))
    h.point(point)


def main():
    # Create an agent
    agent = Agent()

    # Create a handler and pass it an agent so it can write points
    h = RedisHandler(agent)

    # Set the handler on the agent
    agent.handler = h

    # Anything printed to STDERR from a UDF process gets captured into the Kapacitor logs.
    sys.stderr.write("Starting agent for RedisHandler")
    sys.stderr.flush()
    agent.start()
    agent.wait()
    sys.stderr.write("Agent finished")
    sys.stderr.flush()


if __name__ == '__main__':
    # test()
    main()
