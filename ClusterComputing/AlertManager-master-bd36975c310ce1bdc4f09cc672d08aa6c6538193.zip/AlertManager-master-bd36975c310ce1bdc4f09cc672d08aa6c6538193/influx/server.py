from flask import request, Flask

app = Flask(__name__)


@app.route('/')
def hello():
    return 'Hello, World!'


@app.route('/alert', methods=['POST'])
def login():
    process_alert(request.get_json(silent=True))
    return ''


def process_alert(data):
    # print(json.dumps(data, indent=4))
    print(
        f'"id": {data["id"]}\n"Message": {data["message"]}\n"Usage idle": {data["data"]["series"][0]["values"][0][3]}')


if __name__ == '__main__':
    app.run(host='192.168.198.189', debug=True)
