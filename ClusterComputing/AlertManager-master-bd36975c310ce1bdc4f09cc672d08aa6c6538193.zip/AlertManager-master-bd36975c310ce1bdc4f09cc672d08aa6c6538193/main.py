import sys
import argparse

sys.path.extend(['./influx'])

parser = argparse.ArgumentParser()

parser.add_argument('--task', required=True, choices=['consumer', 'producer'])
parser.add_argument('--path', type=str)

args = parser.parse_args()

if __name__ == '__main__':
    if args.task == 'producer':
        from influx.producer import produce_messages

        path = args.path
        if path:
            produce_messages(path)
        else:
            print('Please provide raw file path as "--path path/to/file"')
            exit(1)
    elif args.task == 'consumer':
        from influx.consumer import store_from_kafka

        store_from_kafka()
    else:
        print('Wrong task')
        exit(1)
