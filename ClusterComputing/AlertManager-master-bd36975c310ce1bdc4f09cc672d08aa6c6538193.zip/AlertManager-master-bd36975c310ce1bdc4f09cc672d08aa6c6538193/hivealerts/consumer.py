from kafka import KafkaConsumer
import json
from datetime import datetime, timedelta
import logging
from pyhive import hive, presto

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def store_service_alerts_from_kafka(batch_size=50, seconds_to_wait=1):
    consumer = KafkaConsumer(
        'alarms-service-raw',
        bootstrap_servers='192.168.50.56:9094',
        value_deserializer=lambda value: json.loads(value, encoding='ascii'),
        group_id='hive-service-alerts-consumers'
    )
    cursor = hive.connect(host="inchortapptest01.inceptum.local", port=10000).cursor()
    cursor.execute('SELECT * FROM small_table LIMIT 10')
    print(cursor.fetchone())
    print(cursor.fetchall())
    # values = []
    # last_commit = datetime.now()
    # for record in consumer:
    #     data = record.value
    #     logging.log(logging.INFO, f"Processing message: {json.dumps(data)}")
    #     # values = [data]
    #     # store_values(client, values)
    #     # logging.log(logging.INFO, f"Stored values: {json.dumps(values)}")
    #     values.append(data)
    #     if len(values) > batch_size or last_commit < datetime.now() - timedelta(seconds=seconds_to_wait):
    #         # cursor.execute()
    #         logging.log(logging.INFO, f"Stored values: {json.dumps(values)}")
    #         last_commit = datetime.now()
    #         values = []
    consumer.close()
    cursor.close()


if __name__ == '__main__':
    store_service_alerts_from_kafka()
