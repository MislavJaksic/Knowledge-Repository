
<h1>Kapacitor</h1>
<p>
Package <i>influx.kapacitor</i> contains scripts that are used as Kapacitors UDF scripts<br/>
Each of the scripts is documented with info what each option means 
</p>

<h1>Kafka</h1>
<p>
Module <i>main.py</i> has arguments task and path.<br/>
Task can be either producer or consumer. If task i producer path must be given<br/>
Option path is used for continuous data loading from a raw data source<br/>
Consumer takes json data about interface bandwidth and stores it into a InfluxDB 
</p>

<h1>Inventory loading</h1>
Module <i>inventory.storer.py</i> loads files that should be in inventory path.<br/>
CSV and XLS files are parsed and inventory, consumers and location data is loaded indefinitly into Redis database 